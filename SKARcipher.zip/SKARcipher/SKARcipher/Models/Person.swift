struct Person {
    let firstName: String
    let lastName: String
    let description: String
    let dateOfBirth: String
    let dateOfDeath: String
    let image: String
    
    var fullName: String {
        "\(firstName) \(lastName)"
    }
    
    var livingPeriod: String {
        "\(dateOfBirth) - \(dateOfDeath)"
    }
}
