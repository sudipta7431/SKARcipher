struct Algorithm {
    let name: String
    let creator: Person
    let description: String
}

// MARK: - Extensions
extension Algorithm {
    // MARK: - Public methods
    static func getAlgorithms() -> [Algorithm] {
        AlgorithmsInfoDataManager.shared.algorithmsData
    }
}
